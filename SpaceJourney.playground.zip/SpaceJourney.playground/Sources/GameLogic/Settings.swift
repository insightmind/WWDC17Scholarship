//  Created by Niklas Bülow on 28.03.17.
//  Copyright © 2017 Niklas Bülow. All rights reserved.

import Foundation

public struct Settings{
    
    var showGravity = false

    
}
